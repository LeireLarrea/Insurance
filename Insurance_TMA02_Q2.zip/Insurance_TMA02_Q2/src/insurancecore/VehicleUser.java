
package insurancecore;

import m256date.*;

/**
 * Represents  vehicle users.
 */
public class VehicleUser
{
    /**the maximum number of penalty points allowed for a vehicle user*/
    public static final int MAX_POINTS = 12;

    /**the name of the vehicle user*/
    private final String name;

    /**the  date of birth of the vehicle user*/
    private final M256Date dateOfBirth;

    /**the number of penalty points of the vehicle user:  cannot be more than 12*/
    private int points;


    /**
    *Constructor. Creates a new VehicleUser object with the given name,
    * date of birth and number of penalty points.
    *
    *@param aName the name of the vehicle user
    *@param aDate the date of birth of the vehicle user
    *@param aPoints the number of penalty points of the vehicle user
    *
    
    */
    VehicleUser(String aName, M256Date aDate, int aPoints)
    {
       name = aName;
       dateOfBirth = aDate;
       points = aPoints;
    }
  
   


    /**
     * Returns the name of the vehicle user.
     *
     *@return    name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Returns the  number of penalty points of the vehicle user.
     *
     *@return    points
     */
    public int getPoints()
    {
        return points;
    }


    /**
     * Returns the  age of the vehicle user.
     *
     *@return    age
     */
    public int getAge()
    {
        return dateOfBirth.getAge();
    }


    /**
     * Returns the date of birth of the vehicle user.
     *
     *@return    dateOfBirth
     */
    public M256Date getDateOfBirth()
    {
        return dateOfBirth;
    }



    /**
     *Returns a string representation of the receiver.
     *
     *@return       a string object containing information about the vehicle user
     */

    @Override
    public String toString()
    {
        return  "\n    " + name + ", age " + getAge() + ", penalty points " + points;
    }
}

