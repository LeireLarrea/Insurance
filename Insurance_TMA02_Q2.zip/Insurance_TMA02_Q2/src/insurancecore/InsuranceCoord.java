
package insurancecore;

import java.util.*;
import m256date.*;

/**
 * The coordinating class for the insurancecore
 * package. Public messages in the
 * protocol of this class enable clients to
 * interact with the insurancecore package.
 */
public class InsuranceCoord
{
    /**The policy*/
    private Policy policy;


    /** Creates a new instance of InsuranceCoord */
    public InsuranceCoord()
    {

    }


    /**
     * Sets the policy to a new Policy object.
     *
     *@param aRegistrationNumber    the registration number of the vehicle to be insured
     *@param aName                  the name of the lead vehicle user
     *@param aDate                  the date of birth of the lead vehicle user
     *@param aPoints                the number of penalty points of the lead vehicle user
     *@param aPremium               the base premium of the policy
     *@throws IllegalArgumentException if aPoints is more than the maximum number of penalty points or less than 0
     *
     */
    public void createPolicy(String aRegistrationNumber, String aName, M256Date aDate, int aPoints, int aPremium)
    {
        if (aPoints <= VehicleUser.MAX_POINTS && aPoints >= 0)
        {
            VehicleUser aVehicleUser = new VehicleUser(aName, aDate, aPoints);
            policy = new Policy(aRegistrationNumber, aVehicleUser, aPremium);
        }
        else
        {
           throw new IllegalArgumentException("Too many penalty points");
        }
    }


    /**
     * Adds a new vehicle user to the policy.
     *
     *@param aName    the name of the new vehicle user
     *@param aDate    the date of birth of the new vehicle user
     *@param aPoints  the number of penalty points of the new vehicle user
     *@throws IllegalArgumentException if aPoints is more than the maximum number of penalty points or less than 0
     *
     */
   public void addVehicleUser(String aName, M256Date aDate, int aPoints)
    {
        if (aPoints <= VehicleUser.MAX_POINTS && aPoints >= 0)
        {
            VehicleUser theVehicleUser = new VehicleUser(aName, aDate, aPoints);
            policy.addVehicleUser(theVehicleUser);
        }
         else
        {
           throw new IllegalArgumentException("Too many penalty points");
        }
    }


     /**
     * Removes a vehicle user from the policy. The user must not be the lead user.
     *
     *@param aVehicleUser    the vehicle user to be removed
     *@throws IllegalArgumentException if aVehicleUser is the lead vehicle user
     *
     */
    public void removeVehicleUser(VehicleUser aVehicleUser)
    {
        if ( !aVehicleUser.equals(policy.getVehicleUsers().get(0)))
        {
            policy.removeVehicleUser(aVehicleUser);
        }
         else
        {
           throw new IllegalArgumentException("Cannot remove lead user");
        }
    }

    /**
     *Returns the vehicle users of the policy.
     *The lead vehicle user is the first in the list.
     *
     *@return vehicle users of policy.
     */
    public List<VehicleUser>  getVehicleUsers()
    {
        
        return policy.getVehicleUsers();
       
    }



    /**
     *Returns a string representation of the receiver.
     *
     *@return       a string object containing information about the policy
     */
    @Override
    public String toString()
    {
        return  policy.toString();
    }
}

