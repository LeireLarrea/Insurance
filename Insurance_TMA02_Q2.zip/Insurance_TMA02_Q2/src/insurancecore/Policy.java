

package insurancecore;

import java.util.*;

/**
 *Represents a vehicle policy.
 *The premium consists of a base amount set when the policy is created,
 *increased by £50 for each additional vehicle user aged under 30 when added to the policy,
 *and £20 for each additional vehicle user aged 30 or more when added to the policy.
 */
public class Policy
{
    /**old user age*/
    public static final int OLD_USER_AGE = 30;

    /**additional premium for a young vehicle user*/
    public static final int YOUNG_USER_PREMIUM = 5000;

     /**additional premium for an old vehicle user*/
    public static final int OLD_USER_PREMIUM = 2000;

    /**The vehicle registration number*/
    private final String registrationNumber;

    /**The premium in pence*/
    private int premium;

    /**The authorised users of the vehicle*/
    private final List<VehicleUser> vehicleUsers;


    /**
    *Constructor. Creates a new Policy object with:
    *the given registration number;
    *the given lead vehicle user;
    *the given base premium cost.
    *
    *@param aRegistrationNumber      the vehicle registration number
    *@param aVehicleUser                 the lead vehicle user
    *@param aPremium                 the base premium
    */
    Policy(String aRegistrationNumber, VehicleUser aVehicleUser, int aPremium)
    {
        vehicleUsers = new ArrayList<VehicleUser>();
        vehicleUsers.add(aVehicleUser);
        registrationNumber = aRegistrationNumber;
        premium = aPremium;
    }


    /**
     * Adds a vehicle user to the list.
     *
     *@param   aVehicleUser        a vehicle user
    */
    void addVehicleUser(VehicleUser aVehicleUser)
    {
        vehicleUsers.add(aVehicleUser);
        if (aVehicleUser.getAge() < Policy.OLD_USER_AGE)
        {
            premium = premium + Policy.YOUNG_USER_PREMIUM;
        }
        else
        {
            premium = premium + Policy.OLD_USER_PREMIUM;
        }
    }

    /**
     * Removes a vehicle user from the list.
     *
     *@param   aVehicleUser        the vehicle user to be removed
    */
    void removeVehicleUser(VehicleUser aVehicleUser)
    {
        vehicleUsers.remove(aVehicleUser);
        if (aVehicleUser.getAge() < Policy.OLD_USER_AGE)
        {
            premium = premium - Policy.YOUNG_USER_PREMIUM;
        }
        else
        {
            premium = premium - Policy.OLD_USER_PREMIUM;
        }
       
     }



    /**
     * Returns the vehicle users of the policy.
     * The lead vehicle user is the first in the list.
     *
     *@return    vehicleUsers
     */
    public List<VehicleUser> getVehicleUsers()
    {
       return vehicleUsers;
    }



    /**
     * Returns the premium of the policy in pence.
     *
     *@return  premium
     */
    public int getPremium()
    {
        return premium;
    }


    /**
     * Returns the registration number of the vehicle.
     *
     *@return    registrationNumber
     */
    public String getRegistrationNumber()
    {
        return registrationNumber;
    }


    /**
     *Returns a string representation of the receiver.
     *
     *@return       a string object containing information about the policy
     */
    @Override
    public String toString()
    {
        String returnString;
        List<VehicleUser> vehicleUsersCopy = new ArrayList<VehicleUser>(vehicleUsers);
        returnString = "Policy for vehicle: " + registrationNumber + "\n";
        returnString = returnString + "Vehicle user details: " + "\n"+
              " Lead Vehicle User: " + vehicleUsersCopy.remove(0) +
              "\n Other users: " + vehicleUsersCopy + "\n";
        returnString = returnString + " Premium: " + premium;
        return  returnString;
    }
}

