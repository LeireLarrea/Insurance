

package insuranceclient;

import java.util.*;
import m256date.*;
import insurancecore.*;
import java.text.*;

/*
 * Client of InsuranceCoord.
 */
public class InsuranceClient
{
    /**Creates and manipulates an InsuranceCoord object*/
    public static void main(String[] args) throws ParseException
    {

        InsuranceCoord insurance = new InsuranceCoord();
        insurance.createPolicy("CD12 BT5", "Brian Aldridge", new M256Date("20/11/43"), 3, 50000);
        insurance.addVehicleUser("Jennifer Aldridge", new M256Date("07/01/45"), 6);
        insurance.addVehicleUser("Alice Carter", new M256Date("29/09/88"), 12);


        System.out.println("The initial policy details are: " + "\n" + insurance);
        System.out.println();

        System.out.println("Attempting to remove a vehicle user...");
        insurance.removeVehicleUser(insurance.getVehicleUsers().get(1));
        System.out.println("The new policy details are: " + "\n" + insurance);

        System.out.println("Attempting to remove another vehicle user...");
        List<VehicleUser> vehicleUsers = insurance.getVehicleUsers();
        vehicleUsers.remove(0);
        System.out.println("The new policy details are: " + "\n" + insurance);
    }
}




